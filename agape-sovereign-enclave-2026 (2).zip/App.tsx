import React, { useState, useEffect, useRef, useMemo } from 'react';
import { AppView, UserIdentity, AccountShard, ShardCategory, IdentityFragment } from './types';
import { 
  getArchitectAdvice, 
  validateLiveEmailBatch, 
  simulateInboxFetch, 
  getAccountUsageAnalysis 
} from './services/geminiService';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [view, setView] = useState<AppView>(AppView.DASHBOARD);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  
  // Search & Filtering (Mass Scale)
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTopicFilter, setActiveTopicFilter] = useState<string | null>(null);

  // Security & State
  const [isScanning, setIsScanning] = useState(false);
  const [scanResults, setScanResults] = useState<IdentityFragment[]>([]);
  const [aiAdvice, setAiAdvice] = useState<string>('Enclave standing by. Multi-shard identity mapping in progress.');
  const [isSyncingToCloud, setIsSyncingToCloud] = useState(false);
  const [webAuthnError, setWebAuthnError] = useState<{message: string, tip: string} | null>(null);

  // Shard Management (Multi-Account Scaling)
  const [shards, setShards] = useState<AccountShard[]>([
    { id: 'sh-01', type: 'google', identifier: 'israel.david@gmail.com', category: ShardCategory.EMAIL, status: 'verified', lastSeen: '2m ago', itemCount: 125400, usageProfile: { frequency: 'daily', explanation: 'Primary communications hub. Highly active.', isUtilized: true } },
    { id: 'sh-02', type: 'github', identifier: 'IsraelDavid-Dev', category: ShardCategory.SOCIAL, status: 'verified', lastSeen: '10m ago', itemCount: 450, usageProfile: { frequency: 'daily', explanation: 'Core development identity.', isUtilized: true } },
    { id: 'sh-03', type: 'outlook', identifier: 'israel.office@outlook.com', category: ShardCategory.EMAIL, status: 'verified', lastSeen: '1h ago', itemCount: 8500 },
  ]);

  // Form State for linking new accounts
  const [newShardId, setNewShardId] = useState('');
  const [newShardCategory, setNewShardCategory] = useState<ShardCategory>(ShardCategory.EMAIL);
  const [newShardType, setNewShardType] = useState<AccountShard['type']>('google');
  const [idError, setIdError] = useState('');

  // Local Device Attestation
  const [isAttesting, setIsAttesting] = useState(false);
  const [attestationLogs, setAttestationLogs] = useState<string[]>([]);
  const profileRef = useRef<HTMLDivElement>(null);

  const identity: UserIdentity = {
    id: 'NODE-L3-ALPHA',
    handle: 'Israel David',
    globalSovereignScore: 99,
    lastAttestation: 'Just Now',
    posture: { osSecure: true, biometricsActive: true, pqcReady: true, browserHardened: true, score: 99 }
  };

  const navItems = [
    { id: AppView.DASHBOARD, icon: 'fa-house', label: 'Overview' },
    { id: AppView.SYNC, icon: 'fa-link', label: 'Sources' },
    { id: AppView.MONITOR, icon: 'fa-radar', label: 'Spectre Nuke' },
    { id: AppView.ADMIN, icon: 'fa-microchip', label: 'Admin' },
    { id: AppView.WIKI, icon: 'fa-book', label: 'Lexicon' },
  ];

  const availableTopics = useMemo(() => {
    const topics = new Set(scanResults.map(r => r.aiTopic));
    return Array.from(topics);
  }, [scanResults]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const resolveWebAuthnError = (errorName: string) => {
    switch (errorName) {
      case 'TimeoutError':
        return { message: "Handshake Timed Out.", tip: "Verify hardware key connection or ensure biometric sensor is active." };
      case 'InvalidStateError':
        return { message: "Invalid Authenticator State.", tip: "Passkey already exists or session mismatch. Clear browser credentials and retry." };
      case 'NotAllowedError':
        return { message: "Access Denied by User.", tip: "Permissions rejected. Please authorize the browser's biometric request." };
      case 'SecurityError':
        return { message: "Insecure Context Fault.", tip: "WebAuthn requires HTTPS/L3 Enclave tunnels." };
      default:
        return { message: "Hardware Fault.", tip: "Re-pulse hardware attestation sequence." };
    }
  };

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleLinkShard = (e: React.FormEvent) => {
    e.preventDefault();
    setIdError('');
    
    if (newShardCategory === ShardCategory.EMAIL && !validateEmail(newShardId)) {
      setIdError('Please enter a valid email address.');
      return;
    }
    
    if (!newShardId) {
      setIdError('Identifier is required.');
      return;
    }

    const newShard: AccountShard = {
      id: `sh-${Math.random().toString(36).substr(2, 5)}`,
      type: newShardType,
      identifier: newShardId,
      category: newShardCategory,
      status: 'syncing',
      lastSeen: 'Now',
      itemCount: Math.floor(Math.random() * 50000)
    };

    setShards([newShard, ...shards]);
    setNewShardId('');
    analyzeUsage(newShard.id);
  };

  const analyzeUsage = async (shardId: string) => {
    const shard = shards.find(s => s.id === shardId);
    if (!shard) return;
    const analysis = await getAccountUsageAnalysis(shard.identifier, `${shard.itemCount} entries indexed.`);
    if (analysis) {
      setShards(prev => prev.map(s => s.id === shardId ? { ...s, status: 'verified', usageProfile: analysis } : s));
      syncToFirebase();
    }
  };

  const syncToFirebase = async () => {
    setIsSyncingToCloud(true);
    await new Promise(r => setTimeout(r, 1000));
    setIsSyncingToCloud(false);
    setAiAdvice("Identity Cloud Shard (Firebase) successfully updated.");
  };

  const runHardwareAttestation = async () => {
    setIsAttesting(true);
    setAttestationLogs([
      "[INIT] Contacting Secure Enclave...",
      `[HARDWARE] ${navigator.hardwareConcurrency}-Core Architecture Verified`,
      `[MEM] Attesting ${(navigator as any).deviceMemory || '4'}GB VRAM Footprint`,
    ]);
    const steps = ["[IO] Indexing footprint...", "[SEC] FIDO2 L3 Ready.", "[AUTH] Biometrics: OPTIMAL.", "[OK] NODE SECURED."];
    for (const step of steps) {
      await new Promise(r => setTimeout(r, 600));
      setAttestationLogs(prev => [...prev, step]);
    }
    setIsAttesting(false);
  };

  const handleNukeScan = async () => {
    setIsScanning(true);
    const data = await simulateInboxFetch("Global Multi-Archive", searchQuery);
    const results = await validateLiveEmailBatch(data, searchQuery);
    setScanResults(results);
    setIsScanning(false);
  };

  const nukeFragment = (id: string) => {
    setScanResults(prev => prev.filter(r => r.id !== id));
  };

  const filteredResults = useMemo(() => {
    return scanResults.filter(r => {
      const queryMatch = !searchQuery || 
        r.sender.toLowerCase().includes(searchQuery.toLowerCase()) || 
        r.subject.toLowerCase().includes(searchQuery.toLowerCase());
      const topicMatch = !activeTopicFilter || r.aiTopic === activeTopicFilter;
      return queryMatch && topicMatch;
    });
  }, [scanResults, searchQuery, activeTopicFilter]);

  const triggerAuth = async () => {
    setIsLoggingIn(true);
    await new Promise(r => setTimeout(r, 700));
    setIsAuthenticated(true);
    syncToFirebase();
  };

  if (!isAuthenticated) {
    return (
      <div className="h-screen bg-[#020617] flex items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_50%_50%,#d8b4fe_0%,transparent_70%)]"></div>
        <div className="glass-card max-w-sm w-full p-12 text-center z-10 animate-in fade-in zoom-in duration-500 shadow-2xl">
          <div className="w-20 h-20 bg-slate-900 rounded-3xl mx-auto mb-8 flex items-center justify-center border border-white/10 pulse-ring">
            <i className="fas fa-shield-halved text-3xl text-hybrid"></i>
          </div>
          <h1 className="text-2xl font-black tracking-tight mb-2 text-white uppercase">Sovereign Enclave</h1>
          <p className="text-slate-500 text-[9px] mb-10 uppercase tracking-[0.3em] font-black">Authorized Hardware Access Only</p>
          <button onClick={triggerAuth} className="w-full py-5 btn-diamond text-[10px] font-black">
            {isLoggingIn ? <i className="fas fa-circle-notch fa-spin"></i> : 'Authenticate Shard'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex bg-[#020617] text-[#f8fafc] overflow-hidden">
      {/* SIDEBAR */}
      <aside className={`transition-all duration-300 ${isSidebarOpen ? 'w-64' : 'w-24'} bg-slate-950 border-r border-white/5 flex flex-col z-50`}>
        <div className="p-8 mb-4 flex items-center gap-4">
          <div className="w-12 h-12 min-w-[48px] rounded-2xl btn-diamond flex items-center justify-center shadow-lg">
            <i className="fas fa-shield-halved text-slate-900"></i>
          </div>
          {isSidebarOpen && (
            <div className="animate-in fade-in slide-in-from-left-2">
              <h2 className="text-sm font-black uppercase tracking-tight text-white">Sovereign</h2>
              <p className="text-[8px] font-black text-hybrid uppercase tracking-[0.2em]">Enclave L3</p>
            </div>
          )}
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {navItems.map(item => (
            <button 
              key={item.id}
              onClick={() => setView(item.id)}
              className={`w-full flex items-center gap-5 px-5 py-4 rounded-2xl transition-all group ${view === item.id ? 'sidebar-active shadow-2xl' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
            >
              <i className={`fas ${item.icon} w-6 text-center text-xl ${view === item.id ? 'text-hybrid' : 'group-hover:text-hybrid'}`}></i>
              {isSidebarOpen && <span className="text-[10px] font-black uppercase tracking-[0.2em]">{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="p-8 border-t border-white/5">
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="w-full text-slate-500 hover:text-white transition-colors py-2 bg-white/5 rounded-xl">
            <i className={`fas ${isSidebarOpen ? 'fa-angles-left' : 'fa-angles-right'}`}></i>
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-w-0 relative">
        <header className="h-20 px-10 flex justify-between items-center bg-slate-950/40 backdrop-blur-3xl border-b border-white/5 z-40">
          <div className="flex items-center gap-6">
            <h1 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">
              {navItems.find(n => n.id === view)?.label} // Identity Index 2026
            </h1>
            {isSyncingToCloud && (
              <div className="sync-indicator animate-pulse">
                <i className="fas fa-cloud-arrow-up"></i> Firebase Syncing
              </div>
            )}
          </div>

          <div className="flex items-center gap-6 relative" ref={profileRef}>
             <button onClick={() => setIsProfileOpen(!isProfileOpen)} className="flex items-center gap-4 p-1.5 pl-4 pr-1.5 bg-slate-900 border border-white/10 rounded-2xl hover:border-hybrid/40 transition-all shadow-2xl group">
                <div className="text-right hidden sm:block">
                   <p className="text-[10px] font-black text-white leading-tight uppercase group-hover:text-hybrid transition-colors">{identity.handle}</p>
                   <p className="text-[8px] text-emerald-400 font-bold uppercase tracking-widest">Post-Singularity Status: SECURE</p>
                </div>
                <div className="w-10 h-10 rounded-xl bg-slate-800 border border-white/10 overflow-hidden shadow-inner">
                   <img src={`https://api.dicebear.com/7.x/shapes/svg?seed=${identity.handle}`} alt="Avatar" />
                </div>
             </button>

             {isProfileOpen && (
               <div className="absolute right-0 top-16 w-80 glass-card p-6 z-50 animate-in slide-in-from-top-4 duration-300 shadow-[0_40px_80px_-15px_rgba(0,0,0,0.6)] border-white/10">
                  <div className="flex flex-col items-center pb-6 border-b border-white/5 mb-6">
                     <div className="w-20 h-20 rounded-2xl bg-slate-950 mb-4 border border-white/10 flex items-center justify-center pulse-ring">
                        <i className="fas fa-diamond text-3xl text-hybrid"></i>
                     </div>
                     <p className="text-[11px] font-black text-white uppercase tracking-[0.2em]">Israel David Navarre</p>
                     <div className="flex gap-2 mt-2">
                        <span className="text-[7px] font-black text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full uppercase">Diamond Status</span>
                        <span className="text-[7px] font-black text-hybrid bg-hybrid/10 px-2 py-0.5 rounded-full uppercase">L3-Certified</span>
                     </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-center">
                       <p className="text-[8px] text-slate-500 uppercase font-black tracking-widest">Shards</p>
                       <p className="text-sm font-black text-white">{shards.length}</p>
                    </div>
                    <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-center">
                       <p className="text-[8px] text-slate-500 uppercase font-black tracking-widest">Footprint</p>
                       <p className="text-sm font-black text-white">{(shards.reduce((a,b)=>a+b.itemCount,0)/1000).toFixed(0)}k</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <button onClick={() => { syncToFirebase(); setIsProfileOpen(false); }} className="w-full py-4 bg-hybrid/10 text-hybrid rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-hybrid/20 transition-all border border-hybrid/20 flex items-center justify-center gap-3">
                       <i className="fas fa-cloud-bolt"></i> Push to Firebase
                    </button>
                    <button onClick={() => setIsAuthenticated(false)} className="w-full py-4 bg-red-500/10 text-red-400 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500/20 transition-all border border-red-500/20 flex items-center justify-center gap-3">
                       <i className="fas fa-power-off"></i> Terminate Node
                    </button>
                  </div>
               </div>
             )}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-10">
          {(isScanning || isAttesting) && (
            <div className="max-w-5xl mx-auto mb-10 animate-in fade-in">
               <div className="flex justify-between items-center mb-3">
                 <span className="text-[11px] font-black text-hybrid uppercase tracking-[0.3em]">
                   {isAttesting ? 'Hardware Posture Attestation...' : 'Deep Shard Indexing...'}
                 </span>
                 <span className="text-[11px] font-mono text-slate-500 animate-pulse">FIREBASE_SYNC_ACTIVE</span>
               </div>
               <div className="progress-bar-futuristic"><div className="progress-fill-futuristic"></div></div>
            </div>
          )}

          {view === AppView.DASHBOARD && (
            <div className="max-w-6xl mx-auto space-y-10 animate-in fade-in">
               <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="glass-card p-12 text-center flex flex-col items-center justify-center border-hybrid/20 shadow-2xl relative overflow-hidden group">
                    <div className="absolute -top-10 -right-10 w-32 h-32 bg-hybrid/10 rounded-full blur-3xl group-hover:bg-hybrid/20 transition-all"></div>
                    <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-6">Sovereign Score</h3>
                    <div className="text-7xl font-black text-white tracking-tighter">{identity.globalSovereignScore}%</div>
                    <p className="text-[9px] text-emerald-400 font-bold uppercase mt-6 tracking-[0.5em] animate-pulse">L3-Certified Active</p>
                  </div>
                  <div className="glass-card p-12 md:col-span-2 flex flex-col justify-center border-l-8 border-l-hybrid shadow-2xl">
                    <div className="flex items-center gap-4 mb-4">
                       <i className="fas fa-brain text-hybrid text-xl"></i>
                       <h3 className="text-xl font-black text-white uppercase tracking-tight">Architect Advisory</h3>
                    </div>
                    <p className="text-sm text-slate-400 leading-relaxed italic border-l-2 border-white/5 pl-6 py-2">"{aiAdvice}"</p>
                  </div>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="glass-card p-10 shadow-2xl">
                     <div className="flex justify-between items-center mb-10">
                        <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Hardware Enclave Pulse</h4>
                        <i className="fas fa-microchip text-hybrid"></i>
                     </div>
                     <div className="bg-slate-950 p-6 rounded-3xl font-mono text-[11px] text-emerald-400/90 mb-8 h-60 overflow-y-auto custom-scrollbar border border-white/5 shadow-inner">
                        {attestationLogs.length > 0 ? attestationLogs.map((log, i) => <p key={i} className="mb-2 animate-in slide-in-from-left-4">> {log}</p>) : <p className="opacity-30 italic text-slate-500 text-center mt-20">Awaiting hardware pulse command...</p>}
                     </div>
                     <button onClick={runHardwareAttestation} disabled={isAttesting} className="w-full py-5 btn-diamond text-[10px] font-black">
                        {isAttesting ? <i className="fas fa-spinner fa-spin mr-3"></i> : <i className="fas fa-bolt mr-3"></i>}
                        {isAttesting ? 'Attesting...' : 'Pulse Hardware Enclave'}
                     </button>
                  </div>

                  <div className="glass-card p-10 flex flex-col justify-between shadow-2xl">
                     <div>
                       <div className="flex justify-between items-center mb-10">
                          <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Active Posture Shards</h4>
                          <span className="sync-indicator">Synchronized</span>
                       </div>
                       <div className="space-y-4">
                          {Object.entries(identity.posture).filter(([k]) => k !== 'score').map(([key, val]) => (
                             <div key={key} className="flex justify-between items-center p-5 bg-white/5 rounded-2xl border border-white/5 hover:border-hybrid/30 transition-all cursor-default">
                                <span className="text-[11px] uppercase text-slate-400 font-black tracking-widest">{key.replace(/([A-Z])/g, ' $1')}</span>
                                <div className="flex items-center gap-3">
                                   <span className="text-[10px] font-black text-emerald-400 uppercase">Hardware-Verified</span>
                                   <i className="fas fa-check-double text-emerald-500"></i>
                                </div>
                             </div>
                          ))}
                       </div>
                     </div>
                  </div>
               </div>
            </div>
          )}

          {view === AppView.SYNC && (
            <div className="max-w-6xl mx-auto space-y-10 animate-in slide-in-from-bottom-8">
               <div className="flex justify-between items-end gap-6 mb-12">
                  <div>
                    <h2 className="text-4xl font-black text-white uppercase tracking-tighter">Identity Sources</h2>
                    <p className="text-[10px] text-slate-500 uppercase tracking-[0.4em] font-black mt-2">Manage and AI-Audit Massive Archive Shards</p>
                  </div>
                  <button onClick={syncToFirebase} className="px-8 py-4 bg-slate-900 border border-white/10 rounded-2xl text-[10px] font-black uppercase text-hybrid hover:bg-hybrid/10 transition-all flex items-center gap-3">
                     <i className="fas fa-cloud-arrow-up"></i> Firebase Global Push
                  </button>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
                  <div className="lg:col-span-1">
                    <div className="glass-card p-8 border-hybrid/30 sticky top-10 shadow-2xl">
                      <h4 className="text-[11px] font-black text-white uppercase tracking-widest mb-8">Add New Shard</h4>
                      <form onSubmit={handleLinkShard} className="space-y-6">
                        <div>
                          <label className="block text-[9px] font-black text-slate-600 uppercase mb-3 tracking-widest">Category</label>
                          <select 
                            value={newShardCategory}
                            onChange={(e) => {
                              const cat = e.target.value as ShardCategory;
                              setNewShardCategory(cat);
                              if (cat === ShardCategory.EMAIL) setNewShardType('google');
                              if (cat === ShardCategory.SOCIAL) setNewShardType('github');
                            }}
                            className="w-full bg-slate-950 border border-white/10 rounded-2xl px-5 py-4 text-[11px] text-white focus:outline-none appearance-none shadow-inner"
                          >
                            <option value={ShardCategory.EMAIL}>Email Archive</option>
                            <option value={ShardCategory.SOCIAL}>Social Network</option>
                            <option value={ShardCategory.BANKING}>Financial Shard</option>
                            <option value={ShardCategory.CLOUD}>Cloud Store</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[9px] font-black text-slate-600 uppercase mb-3 tracking-widest">Provider</label>
                          <div className="grid grid-cols-2 gap-2">
                             {(newShardCategory === ShardCategory.EMAIL ? ['google', 'outlook', 'icloud', 'generic-email'] : ['github', 'x-twitter', 'linkedin', 'apple']).map(t => (
                               <button 
                                 key={t}
                                 type="button"
                                 onClick={() => setNewShardType(t as any)}
                                 className={`py-3 rounded-xl border text-[9px] font-black uppercase transition-all ${newShardType === t ? 'bg-hybrid/20 border-hybrid text-white' : 'bg-slate-900 border-white/5 text-slate-500'}`}
                               >
                                 <i className={`fab fa-${t === 'generic-email' ? 'envelope' : t === 'outlook' ? 'microsoft' : t === 'icloud' ? 'apple' : t} mr-2`}></i>
                                 {t}
                               </button>
                             ))}
                          </div>
                        </div>

                        <div>
                          <label className="block text-[9px] font-black text-slate-600 uppercase mb-3 tracking-widest">
                            {newShardCategory === ShardCategory.EMAIL ? 'Email Address' : 'Account Handle / ID'}
                          </label>
                          <input 
                            type="text" 
                            required
                            value={newShardId}
                            onChange={(e) => { setNewShardId(e.target.value); setIdError(''); }}
                            placeholder={newShardCategory === ShardCategory.EMAIL ? "user@example.com" : "@handle"}
                            className={`w-full bg-slate-950 border rounded-2xl px-5 py-4 text-xs text-white placeholder:text-slate-800 focus:outline-none transition-all shadow-inner ${idError ? 'border-red-500' : 'border-white/10 focus:border-hybrid/50'}`}
                          />
                          {idError && <p className="text-[9px] text-red-500 font-black mt-2 uppercase tracking-widest animate-pulse">{idError}</p>}
                        </div>

                        <button type="submit" className="w-full py-5 btn-diamond text-[11px] font-black mt-4 shadow-2xl">Index Multi-Account Shard</button>
                      </form>
                    </div>
                  </div>

                  <div className="lg:col-span-3">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {shards.map(shard => (
                        <div key={shard.id} className="glass-card p-8 border-white/5 hover:border-hybrid/40 transition-all flex flex-col gap-6 shadow-xl relative overflow-hidden group animate-in slide-in-from-right-4">
                           <div className="flex items-center justify-between z-10">
                              <div className="flex items-center gap-6">
                                 <div className="w-16 h-16 rounded-3xl bg-slate-950 border border-white/10 flex items-center justify-center text-3xl text-slate-500 group-hover:text-hybrid transition-all duration-500 shadow-inner">
                                    <i className={`fab fa-${shard.type === 'generic-email' ? 'envelope' : shard.type === 'outlook' ? 'microsoft' : shard.type === 'icloud' ? 'apple' : shard.type}`}></i>
                                 </div>
                                 <div>
                                    <p className="text-sm font-black text-white group-hover:text-hybrid transition-colors">{shard.identifier}</p>
                                    <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-1">{shard.category} Archive • {shard.itemCount.toLocaleString()} Fragments</p>
                                 </div>
                              </div>
                              <div className={`w-3 h-3 rounded-full ${shard.status === 'verified' ? 'bg-emerald-500 shadow-[0_0_15px_#10b981]' : 'bg-amber-500 animate-pulse shadow-[0_0_15px_#f59e0b]'}`}></div>
                           </div>

                           {shard.usageProfile ? (
                              <div className="p-6 bg-slate-950/50 rounded-2xl border border-white/5 z-10 shadow-inner">
                                 <div className="flex items-center justify-between mb-4">
                                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">AI Utilization Profile</span>
                                    <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase ${shard.usageProfile.isUtilized ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-400 border border-red-500/20'}`}>
                                       {shard.usageProfile.frequency} // {shard.usageProfile.isUtilized ? 'Utilized' : 'Dormant'}
                                    </span>
                                 </div>
                                 <p className="text-[11px] text-slate-400 leading-relaxed italic border-l-2 border-hybrid/30 pl-4">"{shard.usageProfile.explanation}"</p>
                              </div>
                           ) : (
                              <button onClick={() => analyzeUsage(shard.id)} className="w-full py-4 bg-slate-900 border border-white/10 rounded-2xl text-[9px] font-black text-slate-400 uppercase hover:text-white hover:bg-hybrid/10 transition-all z-10 shadow-lg">
                                 <i className="fas fa-magnifying-glass-chart mr-2"></i> Execute AI Utilization Audit
                              </button>
                           )}
                        </div>
                      ))}
                    </div>
                  </div>
               </div>
            </div>
          )}

          {view === AppView.MONITOR && (
            <div className="max-w-6xl mx-auto space-y-10 animate-in slide-in-from-bottom-8">
               <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-8 mb-10">
                  <div>
                    <h2 className="text-4xl font-black text-white uppercase tracking-tighter">Spectre Nuke</h2>
                    <p className="text-[10px] text-slate-500 uppercase tracking-[0.4em] font-black mt-2">Granular Search Across Millions of Multi-Shard Archives</p>
                  </div>
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="relative group">
                       <i className="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 text-sm group-focus-within:text-hybrid transition-colors"></i>
                       <input 
                         type="text" 
                         value={searchQuery}
                         onChange={(e) => setSearchQuery(e.target.value)}
                         placeholder="Keyword, Topic, Sender, or Post..."
                         className="pl-14 pr-6 py-4 bg-slate-950 border border-white/10 rounded-2xl text-[11px] text-white w-full md:w-80 focus:border-hybrid/50 outline-none transition-all shadow-inner placeholder:text-slate-800"
                       />
                    </div>
                    <button onClick={handleNukeScan} disabled={isScanning} className="px-10 py-4 btn-diamond text-[10px] font-black shadow-2xl">
                       {isScanning ? <i className="fas fa-dna fa-spin mr-3"></i> : <i className="fas fa-radar mr-3"></i>}
                       {isScanning ? 'Analyzing...' : 'Pulse Deep Archives'}
                    </button>
                  </div>
               </div>

               {availableTopics.length > 0 && (
                 <div className="flex flex-wrap gap-3 mb-10 pb-4 border-b border-white/5">
                    <button onClick={() => setActiveTopicFilter(null)} className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${!activeTopicFilter ? 'bg-hybrid text-slate-950 shadow-[0_0_20px_rgba(216,180,254,0.4)]' : 'bg-slate-900 text-slate-500 hover:text-white border border-white/5'}`}>All Results</button>
                    {availableTopics.map(topic => (
                      <button key={topic} onClick={() => setActiveTopicFilter(topic)} className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTopicFilter === topic ? 'bg-hybrid text-slate-950 shadow-[0_0_20px_rgba(216,180,254,0.4)]' : 'bg-slate-900 text-slate-500 hover:text-white border border-white/5'}`}>{topic}</button>
                    ))}
                 </div>
               )}

               <div className="space-y-6">
                  {filteredResults.length > 0 ? filteredResults.map(res => (
                    <div key={res.id} className="glass-card p-10 flex flex-col md:flex-row items-center justify-between border-white/5 hover:border-hybrid/40 hover:bg-white/5 transition-all group gap-8 animate-in fade-in">
                       <div className="flex items-center gap-10 flex-1">
                          <div className={`w-20 h-20 rounded-3xl flex items-center justify-center text-3xl shadow-inner ${res.riskLevel === 'critical' ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-orange-500/10 text-orange-500 border border-orange-500/20'}`}>
                             <i className="fas fa-radiation"></i>
                          </div>
                          <div className="space-y-2">
                             <div className="flex items-center gap-4">
                                <h4 className="text-lg font-black text-white uppercase tracking-tight group-hover:text-hybrid transition-colors">{res.sender}</h4>
                                <span className="text-[10px] px-3 py-1 bg-slate-900 text-hybrid rounded-xl font-black uppercase border border-hybrid/20">{res.aiTopic}</span>
                             </div>
                             <p className="text-xs font-black text-slate-400">{res.subject}</p>
                             <p className="text-[11px] text-slate-500 font-medium italic leading-relaxed max-w-2xl">"{res.validationLog}"</p>
                          </div>
                       </div>
                       <div className="flex flex-col items-end gap-4 min-w-[200px]">
                          <span className={`text-[10px] font-black uppercase px-4 py-1.5 rounded-full border ${res.riskLevel === 'critical' ? 'bg-red-500/20 text-red-400 border-red-500/30' : 'bg-slate-900 text-slate-500'}`}>{res.riskLevel} Hazard</span>
                          <button onClick={() => nukeFragment(res.id)} className="w-full px-8 py-4 border-2 border-hybrid/50 rounded-2xl text-[11px] font-black text-hybrid uppercase hover:bg-hybrid hover:text-slate-950 transition-all shadow-xl group-hover:scale-105">Nuke Identity Fragment</button>
                       </div>
                    </div>
                  )) : (
                    <div className="p-40 glass-card border-dashed border-2 border-white/10 flex flex-col items-center justify-center opacity-30 text-center">
                       <i className="fas fa-radar text-7xl mb-10 text-hybrid animate-pulse"></i>
                       <h5 className="text-xl font-black text-white uppercase tracking-widest mb-2">Footprint Silent</h5>
                       <p className="text-[10px] font-black uppercase tracking-[0.6em] text-slate-500">Initiate deep pulse to index millions of artifacts</p>
                    </div>
                  )}
               </div>
            </div>
          )}

          {view === AppView.ADMIN && (
            <div className="max-w-6xl mx-auto space-y-12 animate-in slide-in-from-bottom-10">
               <div>
                  <h2 className="text-4xl font-black text-white uppercase tracking-tighter">Enclave Admin</h2>
                  <p className="text-[10px] text-slate-500 uppercase tracking-[0.4em] font-black mt-2">Protocol Calibration & Shard Ledger Status</p>
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="glass-card p-12 shadow-2xl border-hybrid/10">
                     <div className="flex items-center gap-4 mb-10">
                        <i className="fas fa-bug text-hybrid text-xl"></i>
                        <h4 className="text-[11px] font-black text-white uppercase tracking-widest">WebAuthn Protocol Lab</h4>
                     </div>
                     <p className="text-xs text-slate-400 leading-relaxed mb-10">Select a failure vector to observe AI troubleshooting responses for FIDO2/L3 hardware handshakes.</p>
                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {['TimeoutError', 'InvalidStateError', 'NotAllowedError', 'SecurityError'].map(err => (
                          <button 
                            key={err}
                            onClick={() => setWebAuthnError(resolveWebAuthnError(err))}
                            className="px-6 py-5 bg-slate-950 border border-white/10 rounded-2xl text-[10px] text-slate-500 font-black uppercase hover:border-hybrid/60 hover:text-white transition-all text-left group flex items-center justify-between shadow-inner"
                          >
                            {err}
                            <i className="fas fa-chevron-right opacity-0 group-hover:opacity-100 transition-all"></i>
                          </button>
                        ))}
                     </div>
                     {webAuthnError && (
                       <div className="mt-8 p-6 bg-red-500/5 border border-red-500/20 rounded-2xl animate-in fade-in slide-in-from-top-4">
                          <p className="text-xs font-bold text-white mb-2">{webAuthnError.message}</p>
                          <p className="text-[10px] text-slate-400"><span className="text-hybrid font-black uppercase mr-2">Resolution:</span> {webAuthnError.tip}</p>
                       </div>
                     )}
                  </div>

                  <div className="space-y-8">
                    <div className="glass-card p-12 border-l-8 border-l-emerald-500 shadow-2xl">
                      <div className="flex justify-between items-center mb-10">
                        <h4 className="text-[11px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-3">
                           <i className="fas fa-server"></i> Sovereign Node Health
                        </h4>
                        <span className="sync-indicator">Active</span>
                      </div>
                      <div className="space-y-6">
                        <div className="flex justify-between items-center border-b border-white/5 pb-4">
                           <span className="text-[11px] text-slate-500 font-black uppercase tracking-widest">Cloud Database</span>
                           <span className="text-[11px] font-mono text-white">Firebase Enclave Node-1</span>
                        </div>
                        <div className="flex justify-between items-center border-b border-white/5 pb-4">
                           <span className="text-[11px] text-slate-500 font-black uppercase tracking-widest">Machine Identity</span>
                           <span className="text-[11px] font-mono text-white">Google Cloud Run L3</span>
                        </div>
                        <div className="flex justify-between items-center">
                           <span className="text-[11px] text-slate-500 font-black uppercase tracking-widest">AI Quota Status</span>
                           <span className="text-[11px] font-mono text-white">Standard (Free Tier)</span>
                        </div>
                      </div>
                    </div>
                  </div>
               </div>
            </div>
          )}
        </div>

        <footer className="h-16 bg-slate-950/90 backdrop-blur-3xl border-t border-white/5 px-10 flex justify-between items-center z-40">
           <div className="flex items-center gap-4">
              <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_15px_#10b981]"></div>
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">Agape Sovereign Enclave // Israel David // Secure Node 2026</span>
           </div>
        </footer>
      </main>
    </div>
  );
};

export default App;