export enum AppView {
  DASHBOARD = 'dashboard',
  MONITOR = 'monitor',   // SPECTRE NUKE (Granular Search)
  SYNC = 'sync',         // SHARD LINKING (Usage Analysis)
  WIKI = 'wiki',         // LEXICON
  ADMIN = 'admin'        // ENCLAVE ADMIN
}

export enum ShardCategory {
  EMAIL = 'email',
  SOCIAL = 'social',
  CLOUD = 'cloud',
  HARDWARE = 'hardware',
  BANKING = 'banking'
}

export interface AccountShard {
  id: string;
  type: 'google' | 'github' | 'x-twitter' | 'linkedin' | 'apple' | 'outlook' | 'icloud' | 'generic-email';
  identifier: string;
  category: ShardCategory;
  status: 'verified' | 'vulnerable' | 'syncing' | 'offline';
  lastSeen: string;
  itemCount: number; // Total emails/posts
  usageProfile?: {
    frequency: 'daily' | 'monthly' | 'dormant';
    explanation: string;
    isUtilized: boolean;
  };
}

export interface IdentityFragment {
  id: string;
  sender: string;
  subject: string;
  discoveryType: 'PII' | 'SECRET' | 'IDENTITY_BROKER' | 'BIOMETRIC' | 'GENERAL';
  riskLevel: 'critical' | 'high' | 'moderate' | 'safe';
  aiTopic: string;
  validationLog: string;
}

export interface UserIdentity {
  id: string;
  handle: string;
  globalSovereignScore: number;
  lastAttestation: string;
  posture: {
    osSecure: boolean;
    biometricsActive: boolean;
    pqcReady: boolean;
    browserHardened: boolean;
    score: number;
  };
}

export interface WikiEntry {
  term: string;
  category: 'Security' | 'Protocol' | 'Infrastructure' | 'Backend';
  definition: string;
  impact: string;
}