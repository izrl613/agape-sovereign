import { WikiEntry } from './types';

export const WIKI_ENTRIES: WikiEntry[] = [
  {
    term: "SPECTRE NUKE",
    category: "Protocol",
    definition: "An active-monitor protocol derived from Firefox Monitor that hunts for identity leaks (Spectres) across the dark web and initiates immediate NUKE sequences.",
    impact: "Eliminates breach exposures before they can be leveraged by malicious actors."
  },
  {
    term: "CRYPT KNOX",
    category: "Security",
    definition: "The primary digital vault (KNOX) where a user's verified identity shards are stored under hardware-bound encryption.",
    impact: "Ensures PII remains strictly 'KNOXED' and inaccessible to third-party scrapers."
  },
  {
    term: "PHANTOM NUKE",
    category: "Protocol",
    definition: "A heuristic removal engine that targets hidden trackers and 'phantom' cookies that follow users across sessions.",
    impact: "Restores digital invisibility by nuking cross-site tracking beacons."
  },
  {
    term: "SCORCH NUKE",
    category: "Protocol",
    definition: "A high-intensity inbox-cleansing operation (based on Unroll.me logic) that nukes commercial subscription footprints.",
    impact: "Reduces digital clutter and minimizes email-based tracking vectors."
  },
  {
    term: "AEGIS KNOX",
    category: "Security",
    definition: "A persistent removal defense engine (Optery-style) that keeps user data 'KNOXED' by filing automated opt-outs with over 100 data brokers.",
    impact: "Maintains a permanent privacy perimeter around the user's digital identity."
  },
  {
    term: "ECRA 2026 (Sovereign Mandate)",
    category: "Protocol",
    definition: "Electronic Communications Rights Act 2026. This app implements the 'Zero-Knowledge Removal' standard outlined in Section 402.",
    impact: "Legal enforcement of data deletion requests directly via the Enclave."
  },
  {
    term: "PQC Kyber-768",
    category: "Security",
    definition: "Post-Quantum Cryptography algorithm used to secure the Zero Trust tunnel to sovereign.nyc.",
    impact: "Future-proofs communication against decryption by quantum adversaries."
  }
];

export const ECRA_PROTOCOL_RESOURCES = [
  { title: "ECRA 2026 Official Directive", link: "https://example.com/ecra-whitepaper", type: "PDF" },
  { title: "FIDO2 L3 Compliance Doc", link: "https://fidoalliance.org/", type: "DOC" },
  { title: "Sovereign Removal API V1", link: "#", type: "API" }
];
