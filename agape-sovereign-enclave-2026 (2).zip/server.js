const express = require('express');
const path = require('path');
const compression = require('compression');

const app = express();
const PORT = process.env.PORT || 8080;

app.use(compression());

// Health check endpoint for Cloud Run
app.get('/healthz', (req, res) => {
  res.status(200).send('HEALTHY');
});

// Serve static files
app.use(express.static(__dirname));

// Single Page Application (SPA) routing
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`💎 Sovereign Enclave Online | Port ${PORT}`);
});