# Agape Sovereign Security Standards (2026)
**Project Owner:** Israel David Navarre
**Project ID:** agape-sovereign
**User Identifier:** IDIN@AGAPE.NYC

This document outlines the mandatory security protocols for the Agape Sovereign Enclave.

## 1. Zero Trust Architecture (Beyond AI Studio)
To transition from a sandbox to a fully hardened GCP production environment, the following must be configured in your **Google Cloud Console**:

### Identity & Access (IAM)
- **Identity-Aware Proxy (IAP):** Enable IAP for the Cloud Run service. This ensures that even before a request hits the application, it must be authenticated via Google Workspace.
- **Service Account Hardening:** Ensure the service account running the enclave has only `roles/run.invoker` and `roles/secretmanager.secretAccessor`.

### Passkey Implementation (WebAuthn)
- The enclave currently simulates a passkey handshake. For full implementation, the `navigator.credential.create()` API must be tied to a hardware-bound security key (FIDO2 L3).
- **GCP Key Management Service (KMS):** Use KMS to store the public keys for your biometric attestations.

## 2. GCP Free Tier Error Prevention
As the owner of `agape-sovereign`, you may encounter specific Free Tier limitations. Here is what to monitor:

- **E2-Micro Restrictions:** Ensure you are in a supported region (us-west1, us-central1, us-east1) to keep the Compute Engine free.
- **Artifact Registry Quotas:** Free tier limits storage to 5GB. Monitor the registry to ensure old container images are nuked.
- **API Quotas:** Gemini Flash models have rate limits in the free tier (15 RPM). The enclave logic uses retry logic with exponential backoff to mitigate "429 Too Many Requests" errors.

## 3. Deployment Protocol (Sovereign.nyc)
1. **Domain Mapping:** Use Cloud Run Domain Mapping to point `sovereign.nyc` to your service.
2. **SSL/TLS:** Google manages the SSL certificate automatically. Ensure the "Security" tab in Cloud Run shows "Require Tagged Authenticated Users" if you want to enforce the highest Zero Trust level.

---
*Architect Status: Hardened.*
*One Love. Agape Love.*