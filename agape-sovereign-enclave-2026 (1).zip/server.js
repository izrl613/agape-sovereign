const express = require('express');
const path = require('path');
const compression = require('compression');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 8080;

// Enable gzip compression for faster delivery of ESM modules
app.use(compression());

// Standard logging for GCP Cloud Logging
app.use(morgan('[:date[iso]] :method :url :status :res[content-length] - :response-time ms'));

// Health check endpoint for Cloud Run/GCLB
app.get('/healthz', (req, res) => {
  res.status(200).send('HEALTHY');
});

// Serve static files from the current directory
app.use(express.static(__dirname));

// Single Page Application (SPA) routing: 
// All navigation requests are handled by index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

const server = app.listen(PORT, () => {
  console.log(`
  --------------------------------------------------
  💎 AGAPE SOVEREIGN ENCLAVE | ALPHA BUILD ONLINE
  --------------------------------------------------
  PROJECT: Sovereign #2026
  STATUS:  Active & Hardened
  PORT:    ${PORT}
  URL:     https://cloud.run (Assigned by GCP)
  --------------------------------------------------
  One Love. Agape Love. Sovereign #2026
  `);
});

// Graceful shutdown protocol
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Cleaning up Sovereign tunnel...');
  server.close(() => {
    console.log('Sovereign tunnel closed.');
  });
});
