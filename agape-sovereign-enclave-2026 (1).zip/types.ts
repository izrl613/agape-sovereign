
export enum AppView {
  DASHBOARD = 'dashboard',
  SOURCES = 'sources',
  COACH = 'coach',
  REMOVALS = 'removals',
  BREACH = 'breach',
  ENCLAVE = 'enclave',
  ARCHITECT = 'architect',
}

export enum RiskLevel {
  CRITICAL = 'critical',
  HIGH = 'high',
  MODERATE = 'moderate',
  SAFE = 'safe'
}

export type DiscoveryType = 'PII' | 'SECRET' | 'IDENTITY_BROKER' | 'BIOMETRIC' | 'GENERAL';

export interface Breach {
  id: string;
  source: string;
  date: string;
  leakedData: string[];
  severity: RiskLevel;
}

export interface RemovalRequest {
  id: string;
  broker: string;
  status: 'pending' | 'completed' | 'contested';
  sentDate: string;
}

export interface LinkedAccount {
  id: string;
  platform: 'Google' | 'X' | 'Meta' | 'GitHub' | 'LinkedIn';
  handle: string;
  status: 'synced' | 'pending' | 'revoked' | 'syncing';
  lastSync: string;
}

export interface HardwareNode {
  id: string;
  model: string;
  os: string;
  status: 'authenticated' | 'standby' | 'attested';
  lastHandshake: string;
}

export interface ComplianceItem {
  id: string;
  label: string;
  status: 'passed' | 'failed' | 'pending';
  description: string;
}
