
import React, { useState, useEffect, useRef } from 'react';
import { AppView, RiskLevel, ComplianceItem, LinkedAccount, HardwareNode, Breach, RemovalRequest } from './types';
import { simulateInboxFetch, getArchitectAdvice, generateDsarTemplate } from './services/geminiService';
import { PRIVACY_DEFINITIONS_DB } from './constants';

const resolveWebAuthnError = (error: any) => {
  const name = error?.name || 'UnknownError';
  const resolutionMap: Record<string, { title: string; message: string; tips: string[] }> = {
    NotAllowedError: { title: "Handshake Cancelled", message: "User or system security timeout.", tips: ["Check biometric prompt.", "Disable Do Not Disturb."] },
    TimeoutError: { title: "Handshake Timeout", message: "Hardware node failed to respond.", tips: ["Hold finger on sensor.", "Ensure NFC contact."] },
    InvalidStateError: { title: "Node Conflict", message: "Existing L3 binding conflict.", tips: ["Clear browser security keys.", "Re-initialize vault."] },
    UnknownError: { title: "Sovereign Exception", message: "Undocumented L3 driver fault.", tips: ["Refresh Enclave.", "Check Architect logs."] }
  };
  return resolutionMap[name] || resolutionMap.UnknownError;
};

const App: React.FC = () => {
  // --- Auth & Onboarding State ---
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [loginStep, setLoginStep] = useState<'IDLE' | 'PASSKEY' | 'ZEROTRUST' | 'SUCCESS'>('IDLE');
  
  // --- Navigation & UI ---
  const [view, setView] = useState<AppView>(AppView.SOURCES); // Default to Sources post-login
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // --- Security State ---
  const [isSecurityScanning, setIsSecurityScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanResults] = useState<ComplianceItem[]>([
    { id: '1', label: 'Hardware L3 Binding', status: 'passed', description: 'WebAuthn Root verified.' },
    { id: '2', label: 'GCP IAP Tunnel', status: 'passed', description: 'Zero Trust Proxy stable.' },
    { id: '3', label: 'PQC Lattice Sync', status: 'passed', description: 'Kyber Handshake active.' }
  ]);

  // --- Data State ---
  const [linkedAccounts, setLinkedAccounts] = useState<LinkedAccount[]>([
    { id: '1', platform: 'Google', handle: 'architect@sovereign.node', status: 'synced', lastSync: '2m ago' },
    { id: '2', platform: 'X', handle: '@agape_sovereign', status: 'synced', lastSync: '1h ago' },
    { id: '3', platform: 'GitHub', handle: 'agape-core', status: 'pending', lastSync: 'Never' }
  ]);

  const [breaches] = useState<Breach[]>([
    { id: 'b1', source: '2025 LinkedIn Leak', date: '2025-11-12', leakedData: ['Email', 'Work History', 'Geo-tags'], severity: RiskLevel.HIGH },
    { id: 'b2', source: 'TicketMaster Core', date: '2026-01-05', leakedData: ['Partial CC', 'Full Name'], severity: RiskLevel.CRITICAL }
  ]);

  const [removals, setRemovals] = useState<RemovalRequest[]>([
    { id: 'r1', broker: 'Acxiom', status: 'completed', sentDate: '2026-02-10' },
    { id: 'r2', broker: 'Epsilon', status: 'pending', sentDate: '2026-03-01' }
  ]);

  const [syncLogs, setSyncLogs] = useState<string[]>(["[SYSTEM] Enclave core ready.", "[AUTH] L3 Attestation stable."]);
  const [architectChat, setArchitectChat] = useState<{ role: 'user' | 'ai', text: string }[]>([]);
  const [isAskingArchitect, setIsAskingArchitect] = useState(false);
  const [activeError, setActiveError] = useState<{ title: string; message: string; tips: string[] } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // --- Auth Handlers ---
  const handlePasskeyLogin = async () => {
    setIsLoggingIn(true);
    setLoginStep('PASSKEY');
    
    // Simulate WebAuthn Biometric Delay
    await new Promise(r => setTimeout(r, 1500));
    
    setLoginStep('ZEROTRUST');
    setSyncLogs(prev => ["[AUTH] Passkey Handshake Confirmed.", ...prev]);
    
    // Simulate Google Zero Trust / IAP Attestation
    await new Promise(r => setTimeout(r, 1200));
    
    setLoginStep('SUCCESS');
    setSyncLogs(prev => ["[AUTH] Zero Trust Tunnel Established.", ...prev]);
    
    setTimeout(() => {
      setIsAuthenticated(true);
      setIsLoggingIn(false);
      showToast("Sovereign Session Active", "success");
    }, 800);
  };

  // --- Core Handlers ---
  const performSync = async (accountId?: string) => {
    const ids = accountId ? [accountId] : linkedAccounts.map(a => a.id);
    setLinkedAccounts(prev => prev.map(a => ids.includes(a.id) ? { ...a, status: 'syncing' } : a));
    
    for (const id of ids) {
      const acc = linkedAccounts.find(a => a.id === id);
      if (!acc) continue;
      setSyncLogs(prev => [`[SYNC] Auditing ${acc.platform} nodes...`, ...prev.slice(0, 9)]);
      await new Promise(r => setTimeout(r, 2000));
      setLinkedAccounts(prev => prev.map(a => a.id === id ? { ...a, status: 'synced', lastSync: 'Just now' } : a));
    }
    
    if (!accountId) showToast("Global Vault Sync Complete", "success");
    else showToast(`${linkedAccounts.find(a => a.id === accountId)?.platform} Synced`, "success");
  };

  const handleRequestRemoval = async (broker: string) => {
    showToast(`Generating DSAR for ${broker}...`, "info");
    const template = await generateDsarTemplate(broker, "@agape_user");
    setArchitectChat(prev => [...prev, { role: 'ai', text: `### SOVEREIGN DSAR GENERATED: ${broker}\n\n${template}` }]);
    setView(AppView.COACH);
  };

  const askCoach = async (question: string) => {
    if (!question.trim()) return;
    setIsAskingArchitect(true);
    setArchitectChat(prev => [...prev, { role: 'user', text: question }]);
    const context = `View: ${view}, PrivacyScore: 94%, Leaks: 247, Accounts: ${linkedAccounts.length}`;
    const response = await getArchitectAdvice(question, context);
    setArchitectChat(prev => [...prev, { role: 'ai', text: response }]);
    setIsAskingArchitect(false);
  };

  const triggerGlobalNuke = () => {
    showToast("Initiating Global Identity Reclamation...", "error");
    PRIVACY_DEFINITIONS_DB.forEach((def, i) => {
      setTimeout(() => handleRequestRemoval(def.entity), i * 500);
    });
  };

  // --- Render Views ---
  if (!isAuthenticated) {
    return (
      <div className="h-screen bg-[#020617] text-slate-200 flex items-center justify-center font-sans overflow-hidden relative">
        <div className="neon-atmosphere"></div>
        <div className="absolute inset-0 scan-overlay"></div>
        
        <div className="max-w-md w-full px-10 py-16 glass-card rounded-[4rem] border-blue-500/20 text-center z-50 animate-in fade-in zoom-in duration-700">
           <div className="w-24 h-24 rounded-[2rem] bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center shadow-[0_0_40px_rgba(37,99,235,0.4)] border border-white/10 mx-auto mb-10 transition-transform hover:scale-110">
              <i className="fas fa-shield-cat text-4xl text-white"></i>
           </div>
           
           <h1 className="text-4xl font-black text-white uppercase tracking-tighter mb-4">Sovereign Enclave</h1>
           <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em] mb-12">Attest Identity to Enter</p>

           <div className="space-y-6">
              <button 
                onClick={handlePasskeyLogin}
                disabled={isLoggingIn}
                className={`w-full py-6 rounded-3xl text-[11px] font-black uppercase tracking-widest transition-all relative overflow-hidden flex items-center justify-center gap-4 ${isLoggingIn ? 'bg-slate-800 text-slate-500' : 'bg-blue-600 text-white hover:bg-blue-500 shadow-2xl'}`}
              >
                {isLoggingIn ? (
                  <>
                    <i className="fas fa-circle-notch fa-spin"></i>
                    {loginStep === 'PASSKEY' ? 'Requesting Biometric...' : loginStep === 'ZEROTRUST' ? 'Zero Trust Attestation...' : 'Success'}
                  </>
                ) : (
                  <>
                    <i className="fas fa-fingerprint text-lg"></i>
                    Sign In with Passkey
                  </>
                )}
              </button>
              
              <p className="text-[9px] text-slate-600 font-bold uppercase leading-relaxed px-6">
                Protected by Google Identity-Aware Proxy & Passkey L3 Encryption. No Passwords stored.
              </p>
           </div>
        </div>

        <div className="fixed bottom-10 left-10 text-[8px] text-slate-700 font-black uppercase tracking-widest">
           Agape Core v2026.5 // US-CENTRAL1-FREE-TIER
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-[#020617] text-slate-200 flex overflow-hidden font-sans select-none relative">
      <div className="neon-atmosphere"></div>
      
      {/* SIDEBAR */}
      <aside className="w-80 border-r border-white/5 bg-black/50 backdrop-blur-3xl flex flex-col z-50">
        <div className="p-12 flex items-center gap-5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)] border border-white/10">
            <i className="fas fa-shield-cat text-white text-sm"></i>
          </div>
          <h2 className="text-xs font-black uppercase tracking-[0.2em] text-white">Sovereign Core</h2>
        </div>

        <nav className="flex-1 px-6 space-y-3 mt-6 overflow-y-auto">
          {[
            { id: AppView.DASHBOARD, icon: 'fa-layer-group', label: 'Overseer' },
            { id: AppView.SOURCES, icon: 'fa-fingerprint', label: 'Identity Vault' },
            { id: AppView.BREACH, icon: 'fa-radar', label: 'Breach Radar' },
            { id: AppView.REMOVALS, icon: 'fa-trash-can', label: 'Data Purge' },
            { id: AppView.COACH, icon: 'fa-user-shield', label: 'Privacy Coach' },
            { id: AppView.ENCLAVE, icon: 'fa-screwdriver-wrench', label: 'Enclave Admin' }
          ].map(item => (
            <button 
              key={item.id} 
              onClick={() => setView(item.id)} 
              className={`w-full flex items-center gap-5 px-8 py-5 rounded-[2rem] text-[10px] font-black uppercase tracking-widest transition-all ${view === item.id ? 'bg-blue-600/10 text-blue-400 border border-blue-500/30' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
            >
              <i className={`fas ${item.icon} text-base w-6`}></i>
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-10 border-t border-white/5">
           <button 
             onClick={() => { setIsAuthenticated(false); setLoginStep('IDLE'); }} 
             className="w-full py-4 bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-rose-500 hover:border-rose-500/30 rounded-2xl transition-all"
           >
              Revoke Session
           </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 overflow-hidden flex flex-col relative">
        <header className="px-16 py-10 flex justify-between items-center z-40">
           <div className="flex items-center gap-8">
              <div className="w-16 h-16 rounded-full border-2 border-blue-500/40 bg-blue-500/5 flex items-center justify-center diamond-glow">
                <i className="fab fa-google text-3xl text-blue-500"></i>
              </div>
              <div>
                <h1 className="text-4xl font-black sovereign-gradient-text uppercase tracking-tighter">Agape Sovereign</h1>
                <div className="flex items-center gap-3 mt-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-[8px] text-emerald-500 font-black uppercase tracking-widest">Zero Trust Tunnel Established</span>
                </div>
              </div>
           </div>

           <div className="flex items-center gap-8 bg-black/40 border border-white/10 p-5 rounded-[2.5rem] backdrop-blur-3xl">
              <div className="w-12 h-12 rounded-full bg-slate-800 border-2 border-white/10 overflow-hidden shadow-inner">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Aaron" alt="Architect" />
              </div>
              <div className="text-right">
                <p className="text-[10px] font-black text-white uppercase tracking-widest">Agape Love Active</p>
                <p className="text-[9px] text-emerald-500 font-black uppercase mt-1 tracking-widest animate-pulse">L3 ATTESTED</p>
              </div>
           </div>
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-16 pb-32">
          
          {view === AppView.DASHBOARD && (
            <div className="max-w-[1400px] mx-auto space-y-12 animate-in fade-in duration-1000">
               <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                  <div className="glass-card p-12 rounded-[4rem] text-center">
                    <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest mb-10">Privacy Score</h3>
                    <div className="text-7xl font-black text-white mb-4">94<span className="text-blue-500 text-3xl">%</span></div>
                    <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em]">Health Optimized</p>
                  </div>
                  
                  <div className="glass-card p-12 rounded-[4rem] border-blue-500/20 col-span-1 md:col-span-2 flex flex-col justify-between">
                    <div>
                      <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest mb-6 flex items-center gap-3">
                        <i className="fas fa-comment-dots"></i>
                        Coach's Briefing
                      </h3>
                      <p className="text-xl font-bold text-white leading-relaxed">
                        "Welcome back. Your passkey attestation is fresh. First, ensure all accounts in your <span className="text-blue-400">Identity Vault</span> are synced to map your full exposure landscape."
                      </p>
                    </div>
                    <div className="flex gap-4 mt-8">
                       <button onClick={() => askCoach("What should I do first?")} className="px-8 py-3 bg-blue-600 text-white rounded-2xl text-[9px] font-black uppercase tracking-widest transition-transform hover:scale-105">Ask Coach Why</button>
                       <button onClick={() => setView(AppView.SOURCES)} className="px-8 py-3 bg-white/5 border border-white/10 text-white rounded-2xl text-[9px] font-black uppercase tracking-widest hover:bg-white/10">Go to Vault</button>
                    </div>
                  </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                  <div className="glass-card p-12 rounded-[4rem] border-orange-500/20">
                    <h3 className="text-xs font-black text-orange-400 uppercase tracking-widest mb-10">Exposure Surface</h3>
                    <p className="text-3xl font-black text-white mb-2">247 <span className="text-xs text-orange-500 uppercase">Leaks Detected</span></p>
                    <p className="text-[9px] text-slate-500 font-black uppercase leading-loose">Automated reclamation requests are queued for Oracle and Experian clusters.</p>
                  </div>
                  <div className="glass-card p-12 rounded-[4rem] border-emerald-500/20">
                    <h3 className="text-xs font-black text-emerald-400 uppercase tracking-widest mb-10">Success Metrics</h3>
                    <p className="text-3xl font-black text-white mb-2">12 <span className="text-xs text-emerald-500 uppercase">Broker Deletions</span></p>
                    <p className="text-[9px] text-slate-500 font-black uppercase leading-loose">Identity consistency index at 98.2%. Sovereignty is maintained.</p>
                  </div>
               </div>

               <section className="glass-card p-12 rounded-[4rem] border-white/5">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-10">Live Node Status</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                     {[
                       { label: 'Chrome Privacy', status: 'Optimal', icon: 'fa-puzzle-piece' },
                       { label: 'Pixel L3', status: 'Bound', icon: 'fa-mobile-screen' },
                       { label: 'Audit Log', status: 'Clean', icon: 'fa-list-check' },
                       { label: 'Biometrics', status: 'Confirmed', icon: 'fa-fingerprint' }
                     ].map(item => (
                       <div key={item.label} className="p-8 bg-black/40 border border-white/5 rounded-3xl text-center hover:border-blue-500/30 transition-all">
                          <i className={`fas ${item.icon} text-2xl text-blue-500/40 mb-6`}></i>
                          <p className="text-[9px] font-black uppercase text-slate-400 mb-2">{item.label}</p>
                          <p className="text-[10px] font-black uppercase text-emerald-500">{item.status}</p>
                       </div>
                     ))}
                  </div>
               </section>
            </div>
          )}

          {view === AppView.SOURCES && (
             <div className="max-w-[1200px] mx-auto space-y-12 animate-in slide-in-from-bottom-8">
                <header className="flex justify-between items-end">
                   <div>
                     <h1 className="text-6xl font-black text-white uppercase tracking-tighter mb-4">Identity Vault</h1>
                     <p className="text-[11px] text-slate-500 font-black uppercase tracking-[0.5em]">First Step: Connect all Identity Artifacts</p>
                   </div>
                   <button onClick={() => performSync()} className="px-10 py-5 bg-emerald-600 text-white rounded-3xl text-[10px] font-black uppercase tracking-widest shadow-xl flex items-center gap-3 transition-transform hover:scale-105 active:scale-95">
                      <i className="fas fa-rotate"></i>
                      Re-Attest All Nodes
                   </button>
                </header>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   {linkedAccounts.map(acc => (
                     <div key={acc.id} className={`p-10 glass-card rounded-[3rem] flex flex-col justify-between border-blue-500/10 transition-all duration-700 ${acc.status === 'syncing' ? 'bg-blue-600/5 scale-[0.98]' : ''}`}>
                        <div className="flex items-center justify-between mb-8">
                           <div className="flex items-center gap-6">
                              <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center text-3xl">
                                 <i className={`fab fa-${acc.platform.toLowerCase()}`}></i>
                              </div>
                              <div>
                                 <h4 className="text-xl font-black text-white uppercase tracking-tight">{acc.platform}</h4>
                                 <p className="text-[10px] text-slate-500 font-black uppercase">{acc.handle}</p>
                              </div>
                           </div>
                           <button onClick={() => performSync(acc.id)} className="w-12 h-12 rounded-full hover:bg-white/5 flex items-center justify-center text-slate-400">
                              <i className={`fas fa-rotate ${acc.status === 'syncing' ? 'animate-spin' : ''}`}></i>
                           </button>
                        </div>
                        <div className="flex items-center justify-between">
                           <span className={`px-5 py-2 rounded-full text-[9px] font-black uppercase border ${acc.status === 'synced' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-orange-500/10 text-orange-400 border-orange-500/30'}`}>
                              {acc.status}
                           </span>
                           <p className="text-[8px] text-slate-600 font-black uppercase">Sync Frequency: Daily</p>
                        </div>
                     </div>
                   ))}
                   
                   <button onClick={() => showToast("Connector Interface Pending L3 Update")} className="p-10 border-2 border-dashed border-white/5 rounded-[3rem] flex flex-col items-center justify-center text-slate-600 hover:text-white hover:border-white/20 transition-all group">
                      <i className="fas fa-plus-circle text-4xl mb-6 group-hover:scale-110 transition-transform"></i>
                      <p className="text-[10px] font-black uppercase tracking-widest">Connect New Artifact</p>
                   </button>
                </div>
             </div>
          )}

          {view === AppView.BREACH && (
            <div className="max-w-[1200px] mx-auto space-y-12 animate-in slide-in-from-bottom-8">
               <header className="flex justify-between items-center">
                 <div>
                   <h1 className="text-6xl font-black text-white uppercase tracking-tighter mb-4">Breach Radar</h1>
                   <p className="text-[11px] text-slate-500 font-black uppercase tracking-[0.5em]">Real-time Exposure Monitoring</p>
                 </div>
                 <button onClick={() => showToast("Scanning Dark Web nodes...")} className="px-8 py-4 bg-rose-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest">Run Deep Scan</button>
               </header>
               <div className="space-y-6">
                  {breaches.map(b => (
                    <div key={b.id} className="p-10 glass-card rounded-[3rem] flex items-center justify-between group hover:border-rose-500/30">
                       <div className="flex items-center gap-10">
                          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl ${b.severity === RiskLevel.CRITICAL ? 'bg-rose-500/20 text-rose-500 border-rose-500/30' : 'bg-orange-500/20 text-orange-500 border-orange-500/30'} border`}>
                             <i className="fas fa-radiation"></i>
                          </div>
                          <div>
                             <h4 className="text-xl font-black text-white uppercase tracking-tight">{b.source}</h4>
                             <p className="text-[10px] text-slate-500 font-black uppercase mt-2">Leaked Identity Fragments: {b.leakedData.join(', ')}</p>
                          </div>
                       </div>
                       <button onClick={() => askCoach(`How do I fix my exposure in the ${b.source} breach?`)} className="px-6 py-2 bg-white/5 border border-white/10 rounded-xl text-[9px] font-black uppercase opacity-0 group-hover:opacity-100 transition-opacity">Remediate</button>
                    </div>
                  ))}
               </div>
            </div>
          )}

          {view === AppView.REMOVALS && (
            <div className="max-w-[1200px] mx-auto space-y-12 animate-in slide-in-from-bottom-8">
               <header className="flex justify-between items-end">
                 <div>
                   <h1 className="text-6xl font-black text-white uppercase tracking-tighter mb-4">Data Purge</h1>
                   <p className="text-[11px] text-slate-500 font-black uppercase tracking-[0.5em]">Sovereign Reclamation Automation</p>
                 </div>
                 <button onClick={triggerGlobalNuke} className="px-10 py-5 bg-rose-600 text-white rounded-3xl text-[10px] font-black uppercase tracking-widest shadow-xl flex items-center gap-3 hover:bg-rose-500 transition-all">
                    <i className="fas fa-biohazard"></i>
                    Purge All Found
                 </button>
               </header>

               <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {PRIVACY_DEFINITIONS_DB.map(def => (
                    <div key={def.id} className="p-10 glass-card rounded-[3rem] flex flex-col justify-between group hover:border-blue-500/30">
                       <div className="mb-8">
                          <div className="flex justify-between items-start mb-6">
                            <h4 className="text-xl font-black text-white uppercase tracking-widest">{def.entity}</h4>
                            <span className={`text-[8px] font-black uppercase px-3 py-1 rounded-lg border ${def.risk === 'critical' ? 'bg-rose-500/10 border-rose-500/30 text-rose-400' : 'bg-orange-500/10 border-orange-500/30 text-orange-400'}`}>
                               {def.risk}
                            </span>
                          </div>
                          <p className="text-[11px] text-white font-bold uppercase mb-2">{def.pattern}</p>
                          <p className="text-[9px] text-slate-500 font-black uppercase">CCPA 2026 Ready</p>
                       </div>
                       <button 
                        onClick={() => handleRequestRemoval(def.entity)}
                        className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl text-[9px] font-black uppercase text-slate-300 hover:bg-blue-600 hover:text-white transition-all"
                       >
                          Revoke Access
                       </button>
                    </div>
                  ))}
               </div>
            </div>
          )}

          {view === AppView.COACH && (
            <div className="max-w-[1200px] mx-auto h-full flex flex-col md:flex-row gap-12 animate-in slide-in-from-bottom-8 pb-32">
               <aside className="w-full md:w-80 space-y-8">
                  <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest px-4">Privacy Lessons</h3>
                  <div className="space-y-4">
                    {[
                      { q: "What is CCPA 2026?", i: "fa-gavel" },
                      { q: "How do brokers find me?", i: "fa-search" },
                      { q: "L3 Hardware Attestation", i: "fa-key" },
                      { q: "Email Pixel Tracking", i: "fa-eye-slash" }
                    ].map(lesson => (
                      <button 
                        key={lesson.q}
                        onClick={() => askCoach(lesson.q)}
                        className="w-full p-6 glass-card rounded-3xl text-left hover:border-blue-500/30 transition-all flex items-center gap-4 group"
                      >
                         <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform">
                            <i className={`fas ${lesson.i}`}></i>
                         </div>
                         <span className="text-[10px] font-black uppercase text-slate-300 tracking-wider">{lesson.q}</span>
                      </button>
                    ))}
                  </div>
               </aside>

               <div className="flex-1 flex flex-col h-full min-h-0">
                  <header className="mb-8">
                    <h1 className="text-6xl font-black text-white uppercase tracking-tighter mb-2">Privacy Coach</h1>
                  </header>

                  <div className="flex-1 glass-card p-10 rounded-[4rem] flex flex-col min-h-0 border-blue-500/20">
                    <div className="flex-1 overflow-y-auto custom-scrollbar space-y-8 pr-4">
                      {architectChat.length === 0 && (
                        <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
                            <i className="fas fa-user-shield text-6xl mb-6 text-blue-500"></i>
                            <p className="text-[10px] font-black uppercase tracking-widest leading-relaxed">Sovereign Coach Online.<br/>Awaiting Identity Directive.</p>
                        </div>
                      )}
                      {architectChat.map((msg, i) => (
                        <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[85%] p-8 rounded-[2.5rem] text-sm whitespace-pre-wrap leading-relaxed ${msg.role === 'user' ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/10' : 'bg-black/40 border border-white/5 text-slate-300'}`}>
                              {msg.text}
                            </div>
                        </div>
                      ))}
                    </div>
                    
                    <form 
                      onSubmit={(e) => { e.preventDefault(); const inp = (e.currentTarget.elements[0] as HTMLInputElement); askCoach(inp.value); inp.value = ''; }}
                      className="mt-10 flex gap-4"
                    >
                      <input 
                        placeholder="Query the Sovereign Architect..." 
                        className="flex-1 bg-white/5 border border-white/10 rounded-3xl px-10 py-5 text-sm uppercase font-black text-white focus:outline-none focus:border-blue-500/50 transition-all placeholder:text-slate-700" 
                      />
                      <button 
                        type="submit"
                        disabled={isAskingArchitect}
                        className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center text-xl shadow-2xl hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
                      >
                          <i className={`fas ${isAskingArchitect ? 'fa-circle-notch fa-spin' : 'fa-paper-plane'}`}></i>
                      </button>
                    </form>
                  </div>
               </div>
            </div>
          )}

          {view === AppView.ENCLAVE && (
            <div className="max-w-[1400px] mx-auto space-y-12 animate-in slide-in-from-bottom-8">
               <header>
                 <h1 className="text-6xl font-black text-white uppercase tracking-tighter mb-4">Enclave Admin</h1>
                 <p className="text-[11px] text-slate-500 font-black uppercase tracking-[0.5em]">L3 Hardened Infrastructure Control</p>
               </header>
               <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <section className="glass-card p-12 rounded-[4rem] border-blue-500/10">
                     <h3 className="text-xs font-black text-blue-500 uppercase tracking-widest mb-10">Audit Compliance</h3>
                     <div className="space-y-5">
                        {scanResults.map(item => (
                          <div key={item.id} className="p-8 bg-black/40 border border-white/5 rounded-[2.5rem] flex items-center justify-between group">
                             <div className="flex items-center gap-6">
                                <i className={`fas ${item.status === 'passed' ? 'fa-check-circle text-emerald-500' : 'fa-circle-notch fa-spin text-slate-700'} text-2xl group-hover:scale-110 transition-transform`}></i>
                                <div>
                                   <h4 className="text-sm font-black text-white uppercase tracking-widest">{item.label}</h4>
                                   <p className="text-[10px] text-slate-500 font-bold uppercase">{item.description}</p>
                                </div>
                             </div>
                             <button onClick={() => showToast(`Auditing ${item.label}...`)} className="text-[9px] font-black uppercase px-4 py-1.5 rounded-lg bg-white/5 border border-white/10 hover:bg-blue-600 hover:text-white transition-all">Verify</button>
                          </div>
                        ))}
                     </div>
                  </section>
                  
                  <section className="glass-card p-12 rounded-[4rem] border-rose-500/10">
                    <h3 className="text-xs font-black text-rose-400 uppercase tracking-widest mb-10">Termination Protocols</h3>
                    <div className="p-10 bg-black/40 border border-white/5 rounded-[3rem] text-center">
                       <p className="text-[11px] text-slate-500 font-black uppercase mb-10 leading-relaxed">
                          Sovereignty includes the right to be forgotten. This action will purge all L3 bindings and encrypted vault shards permanently.
                       </p>
                       <button onClick={() => showToast("Self-Destruct Sequence Cancelled. Requires Architect confirmation.", "error")} className="w-full py-5 bg-rose-600/10 border border-rose-500/30 text-rose-500 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-600 hover:text-white transition-all">
                          Delete My Data Permanentely
                       </button>
                    </div>
                  </section>
               </div>
            </div>
          )}
        </div>

        {toast && (
          <div className="fixed bottom-16 right-16 z-[2000] animate-in slide-in-from-right-16">
             <div className="px-12 py-7 rounded-[3rem] bg-slate-900/90 border border-blue-500/30 text-blue-400 backdrop-blur-3xl shadow-2xl flex items-center gap-6">
                <div className={`w-3 h-3 rounded-full animate-pulse ${toast.type === 'error' ? 'bg-rose-500 shadow-[0_0_15px_#f43f5e]' : toast.type === 'success' ? 'bg-emerald-500 shadow-[0_0_15px_#10b981]' : 'bg-blue-500 shadow-[0_0_15px_#3b82f6]'}`}></div>
                <span className="text-xs font-black uppercase text-white tracking-[0.3em]">{toast.message}</span>
             </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
